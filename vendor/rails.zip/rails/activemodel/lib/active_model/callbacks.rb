require 'active_model/core'

module ActiveModel
  module Callbacks
    
  end
end